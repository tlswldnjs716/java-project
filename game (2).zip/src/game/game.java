package game;

import javax.swing.JFrame;

public class game extends JFrame{
	   public Main main = null;
	   public MyPanel mypanel = null;
		   public void change(String panelName) {
			      if(panelName.equals("mypanel")) {
			         getContentPane().removeAll();
			         getContentPane().add(mypanel);
			         revalidate();
			         repaint();      
			      }
			   }
	   public static void main(String[] args) {
		      game win = new game();
		      win.setTitle("�� �ޱ� ����");
		      win.main = new Main(win);
		      win.mypanel = new MyPanel(win);
		      win.add(win.main);
		      win.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		      win.setSize(500, 300);
		      win.setVisible(true);
		   }
		}